package com.cg.project.controllers;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.project.beans.Account;
import com.cg.project.beans.Transaction;
import com.cg.project.exceptions.AccountBlockedException;
import com.cg.project.exceptions.AccountNotFoundException;
import com.cg.project.exceptions.BankingServicesDownException;
import com.cg.project.exceptions.InsufficientAmountException;
import com.cg.project.exceptions.InvalidAccountTypeException;
import com.cg.project.exceptions.InvalidAmountException;
import com.cg.project.exceptions.InvalidPinNumberException;
import com.cg.project.services.BankingServices;

@Controller
public class AccountController {
	@Autowired
	private BankingServices bankingServices;
	@RequestMapping("/registerAccount")
	public ModelAndView registerAccountAction(@Valid @ModelAttribute Account account,BindingResult result,HttpSession session) throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		
		if(result.hasErrors())
			return new ModelAndView("registrationPage");
		account=bankingServices.openAccount(account);
		session.setAttribute("account", account);
		return new ModelAndView ("registrationSuccess","account",account);
		
	}
	
	@RequestMapping("/loginAccount")
	public ModelAndView loginAccountAction(@Valid @ModelAttribute Account account,BindingResult result,HttpSession session) throws AccountNotFoundException, BankingServicesDownException {
		if(result.hasErrors())
			return new ModelAndView("loginPage");
		
		
		Account account2=bankingServices.getAccountDetails(account.getAccountNo());
		if((account2.getAccountNo()==account.getAccountNo())&&(account.getPinNumber()==account2.getPinNumber())) {
			session.setAttribute("account", account2);
			return new ModelAndView ("loginSuccessPage","account",account2);
		}
		return new ModelAndView("loginPage");
	}
	
	@RequestMapping("/depositAccount")
	public ModelAndView depositAccountAction(@Valid @ModelAttribute Account account,BindingResult result,HttpSession session) throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		if(result.hasErrors())
			return new ModelAndView("loginPage");
		Account account1=(Account)session.getAttribute("account");
		float amount=bankingServices.depositAmount(account1.getAccountNo(), account.getAccountBalance());
		return new ModelAndView("depositAmountPage","amount",amount);
	}
	
	@RequestMapping("/withdrawAmount")
	public ModelAndView withdrawAmoutAction(@Valid @ModelAttribute Account account,BindingResult result,HttpSession session) throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		if(result.hasErrors())
			return new ModelAndView("loginPage");
		Account account1=(Account)session.getAttribute("account");
		float amount=bankingServices.withdrawAmount(account1.getAccountNo(), account.getAccountBalance(),account.getPinNumber());
		return new ModelAndView("withdrawAmountPage","amount",amount);
	}
	
	@RequestMapping("/fundTransfer")
	public ModelAndView fundTransferAction(@Valid @ModelAttribute Account account,BindingResult result,HttpSession session) throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		if(result.hasErrors())
			return new ModelAndView("loginPage");
		Account account1=(Account)session.getAttribute("account");
		bankingServices.fundTransfer(account.getAccountNo(),account1.getAccountNo(),account.getAccountBalance(),account1.getPinNumber());
		String message="amount transferred sucessfully";
		return new ModelAndView("fundTransferPage","message",message);
	}
	@RequestMapping("/getAllTransactionDetails")
	public ModelAndView getAllTransactionDetailsAction(@Valid @ModelAttribute Account account,BindingResult result,HttpSession session) throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		if(result.hasErrors())
			return new ModelAndView("loginPage");
		Account account1=(Account)session.getAttribute("account");
		List<Transaction>transactions=bankingServices.getAccountAllTransaction(account1.getAccountNo());
		return new ModelAndView("fundTransferPage","transactions",transactions);
		
	}
}

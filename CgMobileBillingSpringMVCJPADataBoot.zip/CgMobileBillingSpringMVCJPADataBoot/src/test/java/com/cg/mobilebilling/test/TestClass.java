package com.cg.mobilebilling.test;
import org.easymock.EasyMock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.mobilebilling.services.BillingServices;
import com.cg.mobilebilling.services.BillingServicesImpl;


public class TestClass {
	
	private BillingServices billingServices;
	
	@BeforeClass
	public void setUpTestEnv(){
		billingServices=EasyMock.createMock(BillingServices.class);
		billingServices=new BillingServicesImpl();
		//mockAssociateDAO=EasyMock.mock(AssociateDAO.class);
		//payrollServices=new PayrollServicesImpl(mockAssociateDAO);
	}
	/*private static AssociateDAO mockAssociateDAO;
	private static PayrollServices payrollServices;
	@BeforeClass
	public void setUpTestEnv(){
		mockAssociateDAO=EasyMock.mock(AssociateDAO.class);
		payrollServices=new PayrollServicesImpl(mockAssociateDAO);
	}
	@Before
	public void setUpTestData(){
		Associate associate1 = new Associate(1001, 78000, "Satish", "Mahajan", "Training", "Manager", "DTDYF736",
				"satish.mahajan@capgemini.com",new BankDetails(12345, "HDFC", "HDFC0097"), new Salary(35000, 1800, 1800));
		
		Associate associate2 =new Associate(1002, 87372, "Ayush", "Mahajan", "Training", "Manager", "YCTCC727",
				"ayush.mahajan@capgemini.com", new BankDetails(12345, "HDFC", "HDFC0097"),new Salary(87738, 1800, 1800));
		
		ArrayList<Associate> associatesList = new ArrayList<>();
		associatesList.add(associate1);
		associatesList.add(associate2);
		
		Associate associate3 =new Associate( 65440, "Mayur", "Patil", "ADC", "Trainee", "CYYJUUF887",
				"mayur.patil@capgemini.com",new BankDetails(123738, "HDFC", "HDFC0097"),new Salary(86222, 1800, 1800));
		
		EasyMock.expect(mockAssociateDAO.findOne(1234)).andReturn(null);
		EasyMock.expect(mockAssociateDAO.findOne(1001)).andReturn(associate1);
		EasyMock.expect(mockAssociateDAO.findOne(1002)).andReturn(associate2);
		
		EasyMock.expect(mockAssociateDAO.findAll()).andReturn(associatesList);
		EasyMock.expect(mockAssociateDAO.save(associate3)).andReturn(associate3);
	}
	@Test(expected = AssociateDetailsNotFoundException.class)
	public void testAssociateDataForInvalidAssociateId() throws PayrollServicesDownException, AssociateDetailsNotFoundException{
		payrollServices.getAssociateDetails(1234);
	}
	public void testAssociateDataForValidAssociateId() throws PayrollServicesDownException, AssociateDetailsNotFoundException{
		Associate expectedAssociate=new Associate(1001, 78000, "Satish", "Mahajan", "Training", "Manager", "DTDYF736",
				"satish.mahajan@capgemini.com",new BankDetails(12345, "HDFC", "HDFC0097"), new Salary(35000, 1800, 1800));
		Associate actualAssociate=payrollServices.getAssociateDetails(1001);
		EasyMock.verify(mockAssociateDAO.findOne(1001));
		assertEquals(expectedAssociate, actualAssociate);
		
	}
	@Test
	public void testGetAssociateDataForValidAssociateId()
			throws PayrollServicesDownException, AssociateDetailsNotFoundException{
		Associate expectedAssociate = new Associate(1001, 78000, "Satish", "Mahajan", "Training", "Manager", "DTDYF736",
				"satish.mahajan@capgemini.com", new BankDetails(12345, "HDFC", "HDFC0097"),new Salary(35000, 1800, 1800));
		Associate actualAssociate = payrollServices.getAssociateDetails(1001);
		
		EasyMock.verify(mockAssociateDAO.findOne(1001));
		assertEquals(expectedAssociate, actualAssociate);
	}

	@Test
	public void testAcceptAssociateDetailsForValidData() throws PayrollServicesDownException {
		int expectedAssociateId = 1003;
		int actualAssociateId = payrollServices.acceptAssociateDetails(15000, "Gajendra", "Hedau", "ADM", "Sr. Analyst", "ADGMK5776G", "gaj@gmail.com", 15000, 1200, 1200, 1276834654l, "HDFC", "HDFC00076");
		assertEquals(expectedAssociateId, actualAssociateId);
	}

	@Test(expected = AssociateDetailsNotFoundException.class)
	public void testCalculateNetSalaryForInvalidAssociateId()
			throws PayrollServicesDownException, AssociateDetailsNotFoundException {
		payrollServices.getAssociateDetails(63363);
	}

	@Test
	public void testCalculateNetSalaryForValidAssociateId() {
		fail();
	}

	@Test
	public void testGetAllAssociatesDetails() throws PayrollServicesDownException {
		Associate associate1 = new Associate(1001, 78000, "Satish", "Mahajan", "Training", "Manager", "DTDYF736",
				"satish.mahajan@capgemini.com",new BankDetails(12345, "HDFC", "HDFC0097"), new Salary(35000, 1800, 1800)
				);
		Associate associate2 =new Associate(1002, 87372, "Ayush", "Mahajan", "Training", "Manager", "YCTCC727",
				"ayush.mahajan@capgemini.com", new BankDetails(12345, "HDFC", "HDFC0097"),new Salary(87738, 1800, 1800)
				);
		ArrayList<Associate> expectedAssociateList = new ArrayList<>();
		expectedAssociateList.add(associate1);
		expectedAssociateList.add(associate2);
		
		
		ArrayList<Associate> actualAssociateList = payrollServices.getAllAssociateDetails();
		assertEquals(expectedAssociateList,actualAssociateList);
		
		
	}
	@After
	public void tearDownTestData() {
		
	}
	
	@AfterClass
	public static void tearDownTestEnv() {
		mockAssociateDAO=null;
		payrollServices=null;
	}*/
}

